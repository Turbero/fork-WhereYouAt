> # (Latest listed first)
>
> ### v1.0.8
> - Update some internal code. Should help with some issues.
> ### v1.0.7
> - Mistlands Update
> ### v1.0.6
> - Update ServerySync internally
> ### v1.0.5
> - Update ServerySync internally
> - Update WIL compatibility naming for new GUID.
> ### v1.0.4
> - Update ServerSync internally
> - Make sure error on version mismatch is bigger
> ### v1.0.3
> - WIL compatibility update for WIL v3.0.1
> ### v1.0.2
> - Version string issue fix.
> ### v1.0.1
> - Attempt at fixing version string load.
> ### v1.0.0
> - Initial Release